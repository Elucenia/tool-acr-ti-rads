# ACR TI-RADS

ELUCENIA · Felipe Guedes. Prepared as a local publication pilot bound to current website build `osjJNvW6DuXxOifbRu_hV`; publication/deployment are separate actions.

## Documentation in ten languages

- [Português (Brasil)](documentation/pt-BR.md) · [ELUCENIA](https://elucenia.org/pt-br/ferramentas/acr-ti-rads)
- [English](documentation/en.md) · [ELUCENIA](https://elucenia.org/en/tools/acr-ti-rads)
- [Español](documentation/es.md) · [ELUCENIA](https://elucenia.org/es/herramientas/acr-ti-rads)
- [Français](documentation/fr.md) · [ELUCENIA](https://elucenia.org/fr/outils/acr-ti-rads)
- [Deutsch](documentation/de.md) · [ELUCENIA](https://elucenia.org/de/werkzeuge/acr-ti-rads)
- [Italiano](documentation/it.md) · [ELUCENIA](https://elucenia.org/it/strumenti/acr-ti-rads)
- [العربية](documentation/ar.md) · [ELUCENIA](https://elucenia.org/ar/tools/acr-ti-rads)
- [中文](documentation/zh.md) · [ELUCENIA](https://elucenia.org/zh/tools/acr-ti-rads)
- [日本語](documentation/ja.md) · [ELUCENIA](https://elucenia.org/ja/tools/acr-ti-rads)
- [हिन्दी](documentation/hi.md) · [ELUCENIA](https://elucenia.org/hi/tools/acr-ti-rads)

The README introduction is in English; the linked usage, field, method, limits, source and review documentation is available in each listed language. Bibliographic titles and schema identifiers retain their source identity.

## Run locally

Serve this directory with a static HTTP server and open `index.html`. Use the language selector or `?lang=en`, `?lang=ar`, etc. All ten interfaces use the portal’s exact numeric parser, numbering formatter and result localizer; each method uses its local browser implementation. Calculation has no fetch, remote API, telemetry or offsite tool dependency. Bibliographic links are source references. `calculator.js` is the Node integration entry.

## Sources, edition and evidence

Recorded method edition: ACR TI-RADS 2017; benign composition rule checked against ACR worksheet on 2026-10-03.

`tool.json` records method/input contracts, source/access limitations, scopes and distinct arithmetic review evidence. `examples.json` retains original synthetic input/expected values; `results.json` records each packaged obtained output, checked assertion and original tolerance. Run `node test.cjs` for all packaged cases: five original reference cases plus1,035 independent synthetic point/diameter cases. These are replayed frozen expectations; they are not clinical validation.

The official ACR worksheet and assessment-category chart were freshly opened on2026-10-05. The white-paper full text was not retrieved. The source record states the exact implementation subset and the one-point category limitation.

This34-file update payload does not include the protected LICENSE/NOTICE/attribution/CI files already in the target repository. Preserve those existing files when applying the update. It is a local package, not evidence of a GitHub commit or a production deployment.

The ten UI records are authorial implementation translations, not certified or official licensed editions. Independent clinical review, professional language approval and instrument rights clearance have **not been performed**. Technical usability and arithmetic reproducibility are separate from diagnosis, treatment or clinical applicability. Never interpret catalog presence as approval.

## License and attribution

Preserve LICENSE, NOTICE, AUTHORSHIP.md, CITATION.cff, SECURITY.md and existing CI/attribution files. Apache-2.0 applies to ELUCENIA code only; this update grants no new rights to instruments, questionnaires, publications, translations, data or marks. Original method authors/rights holders remain in the source record.
