'use strict';
const assert=require('node:assert/strict'),api=require('./calculator.js'),cases=require('./examples.json'),provenance=require('./provenance.json'),fs=require('node:fs'),crypto=require('node:crypto');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
for(const [file,expected] of Object.entries(provenance.packageImplementationFiles))assert.equal(sha(fs.readFileSync(file)),expected,file+' frozen hash');
let assertions=0,interpretationsNotExposed=0;
for(const c of cases){const r=api.calculate(c.input),e=c.expected;if(e.error||e.expectedRejection){assert.ok(typeof r.error==='string'&&r.error.length,c.label);assertions++;continue;}assert.ok(!r.error,c.label+': '+r.error);assertions++;
if(c.kind==='independent-extra'){for(const [k,v]of Object.entries(typeof e.expectedRounded==='number'?{value:e.expectedRounded}:e.expectedRounded)){assert.ok(typeof r.raw?.[k]==='number'&&Math.abs(r.raw[k]-v)<=1e-10,c.label+' / '+k);assertions++;}continue;}
if(e.main!==undefined){assert.equal(r.main?.[0],e.main,c.label+' main');assertions++;}if(e.score!==undefined){assert.equal(r.raw?.score,e.score,c.label+' score');assertions++;}for(const [k,v]of Object.entries(e.raw||{})){const a=r.raw?.[k],tol=e.tol??(typeof v==='number'&&!Number.isInteger(v)?0.5*10**-(String(v).split('.')[1]?.length||0)+1e-8:1e-8);if(typeof v==='number')assert.ok(typeof a==='number'&&Math.abs(a-v)<=tol,c.label+' / '+k);else assert.deepEqual(a,v,c.label+' / '+k);assertions++;}for(const k of ['level','verdict'])if(Object.hasOwn(e,k)&&!Object.hasOwn(r,k))interpretationsNotExposed++;}
console.log(JSON.stringify({cases:cases.length,assertions,interpretationsNotExposed,clinicalApproval:'not-performed',professionalLanguageApproval:'not-performed'}));
